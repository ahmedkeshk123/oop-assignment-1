import java.util.Date;

public class Account
{
    private int ip ;
    private  double balance;

    private static double annualInterestRate;

    private Date dateCreated;

    public Account ()
    {
      dateCreated=new Date();
    }
    public Account (int ip , double balance )
    {
        this.ip=ip;
        this.balance=balance;
        dateCreated=new Date();
    }

    public int getIp() {
        return ip;
    }

    public void setIp(int ip) {
        this.ip = ip;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public double getAnnualInterestRate() {
        return annualInterestRate;
    }

    public void setAnnualInterestRate(double annualInterestRate) {
        this.annualInterestRate = annualInterestRate;
    }

    public Date getDateCreated() {
        return dateCreated;
    }

    public void setDateCreated(Date dateCreated) {
        this.dateCreated = dateCreated;
    }
    public double getMonthlyInterestRate()
    {
    return annualInterestRate/12;
    }
    public double getMonthlyInterest()
    {
        return annualInterestRate*balance;
    }
    public void withdraw(double amount)
    {
      if (balance>amount)
      {
        balance=balance-amount;
      }else
      {
          System.out.println("there is not enough balance");
      }

    }
    public void deposit(double amount)
    {
         balance=balance+amount;
    }
    @Override
    public String toString() {
        return "\tAccount" +
                "\tip=" + ip +
                ", \tbalance=" + balance +
                ",\t dateCreated=" + dateCreated ;

    }
}
