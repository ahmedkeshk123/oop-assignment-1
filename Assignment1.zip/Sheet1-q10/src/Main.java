public class Main {
    public static void main(String[] args) {

        Account rf = new Account(1122 , 20000);
        rf.setAnnualInterestRate(4.5/100);
        rf.withdraw(2500.0);
        rf.deposit(3000.0);
        System.out.println(rf.toString());
    }
}