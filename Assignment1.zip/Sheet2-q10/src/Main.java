public class Main {
    public static void main(String[] args) {
        Person person = new Person("keshk", "smouha",
                "0110001960"keshk@gmail.com");

        Student student = new Student("Mahmoud", "kafer abdo", "01100019561",
                "mahamed@gmail.com", Student.JUNIOR);

        Employee employee = new Employee("ahmed", "mayami", "01100019562",
                "ahmed@gmail.com", 910, 60000);

        Faculty faculty = new Faculty("yasmin", "sha5 zaid", "01100019563",
                "yasmin@gmail.com", 100, 60000, "5pm to 6pm", "Professor");

        Staff staff = new Staff("Essam", "ba7ry", "01100019564",
                "Esssm@gmail.com", 11, 76000, "Executive Assistant");


        System.out.println(person.toString());
        System.out.println(student.toString());
        System.out.println(employee.toString());
        System.out.println(faculty.toString());
        System.out.println(staff.toString());
    }
}